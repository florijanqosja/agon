const Index = () => {
  return <div>HomeP</div>;
};

export default Index;
