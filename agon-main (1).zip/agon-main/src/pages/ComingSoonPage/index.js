const Index = () => {
  return <div>New Feature P</div>;
};

export default Index;
