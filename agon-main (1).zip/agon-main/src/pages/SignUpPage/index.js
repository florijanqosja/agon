const Index = () => {
  return <div>SignUpP</div>;
};

export default Index;
