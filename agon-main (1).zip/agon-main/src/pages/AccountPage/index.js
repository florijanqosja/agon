const Index = () => {
  return <div>AccountP</div>;
};

export default Index;
