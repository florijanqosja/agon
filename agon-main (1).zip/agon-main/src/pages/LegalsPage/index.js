const Index = () => {
  return <div>LegalsP</div>;
};

export default Index;
