const Index = () => {
  return <div>CheckOutP</div>;
};

export default Index;
