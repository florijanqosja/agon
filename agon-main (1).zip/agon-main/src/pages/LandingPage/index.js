const Index = () => {
  return <div>LandingP</div>;
};

export default Index;
