const Index = () => {
  return <div>404P</div>;
};

export default Index;
