const Index = () => {
  return <div>All Components tester</div>;
};

export default Index;
