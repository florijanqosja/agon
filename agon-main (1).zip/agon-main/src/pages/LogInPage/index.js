const Index = () => {
  return <div>LoginP</div>;
};

export default Index;
